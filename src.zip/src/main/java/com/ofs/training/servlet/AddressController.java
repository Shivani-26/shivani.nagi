package com.ofs.training.servlet;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ofs.training.service.Address;
import com.ofs.training.service.AddressService;

@Controller
public class AddressController {

    @Autowired
    AddressService addressService;

    @RequestMapping(value = "/address", method = RequestMethod.GET)
    protected String doGetAll(Model model) throws Exception {
        model.addAttribute("address", new Address());
        model.addAttribute("listPersons", this.addressService.readAll());
        return "address";
        
    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.GET)
    protected String doGet(@RequestBody Address address, @PathVariable ("id") long id, Model model) throws Exception {
        model.addAttribute("address", addressService.read(address));
        return "address";

    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.POST)
    protected String doPost(@ModelAttribute("address") Address address) throws Exception {
        this.addressService.update(address);
        return "address";
        
    }
    @RequestMapping(method = RequestMethod.PUT)
    protected String doPut(@ModelAttribute("address") Address address) throws Exception {
        addressService.create(address);
        return "address";
    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.DELETE)
    protected String doDelete(@PathVariable ("id") long id) throws Exception {
        addressService.delete(id);
        return "address";
    }
}
