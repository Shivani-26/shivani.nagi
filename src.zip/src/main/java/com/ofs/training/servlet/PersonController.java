package com.ofs.training.servlet;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ofs.training.service.Person;
import com.ofs.training.service.PersonService;

@Controller
public class PersonController {

    @Autowired
    PersonService personService;

    @RequestMapping(value = "/person", method = RequestMethod.GET)
    protected String doGetAll(Model model) throws Exception {
        model.addAttribute("person", new Person());
        model.addAttribute("listPersons", this.personService.readAll());
        return "person";
        
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.GET)
    protected String doGet(@RequestBody Person person, @PathVariable ("id") long id, Model model) throws Exception {
        model.addAttribute("person", this.personService.read(person, false));
        return "person";

    }
    @RequestMapping(method = RequestMethod.PUT)
    protected String doPut(@ModelAttribute("person") Person person) throws Exception {
        this.personService.create(person);
        return "person";
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.POST)
    protected String doPost(@ModelAttribute("person") Person person) throws Exception {
        this.personService.update(person);
        return "person";
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.DELETE)
    protected String doDelete(@PathVariable ("id") long id) throws Exception {
        this.personService.delete(id);
        return "person";
    }
}
