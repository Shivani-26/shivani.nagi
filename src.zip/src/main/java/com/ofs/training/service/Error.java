package com.ofs.training.service;

public enum Error {

    INVALID_PERSON_ID("P01ID", "person id should not be zero"), INVALID_FIRST_NAME("P02FN",
            "firstname should not be null"), INVALID_LAST_NAME("P03LN", "lastname should not be null"), INVALID_EMAIL(
                    "P04E", "email should not be null"), INVALID_BIRTH_DATE("P05BD",
                            "birth date must be in 'dd-mm-yyyy' this format"),

    INVALID_ADDRESS_ID("A01ID", "address id should not be zero"), INVALID_STREET("A02S",
            "street should not be null"), INVALID_CITY("A03C",
                    "city should not be null"), INVALID_POSTAL_CODE("A04PC", "postal code should not be null"),

    CONNECTION_NOT_FOUND("100", "Service is not available"), SQL_EXCEPTION("200",
            "Server error"), DUPLICATE_EMAIL("300", "This email id already exists"),

    URL_ERR("400", "The entered url is invalid"), UNAUTHENTICATED_USER("500",
            "The user is not authenticated"), ACCESS_DENIED("600", "User not allowed to access this page");
    private final String CODE;
    private final String ERROR_MESSAGE;

    private Error(String CODE, String ERROR_MESSAGE) {
        this.CODE = CODE;
        this.ERROR_MESSAGE = ERROR_MESSAGE;
    }

    public String getCode() {
        return CODE;
    }

    public String getError_Message() {
        return ERROR_MESSAGE;
    }
}
