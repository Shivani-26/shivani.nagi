package com.ofs.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AuthenticationService {

    public Person login(String email, String password) throws Exception {

        ConnectionManager manager = new ConnectionManager();
        Connection connection = manager.initConnection();

        String isAdmin = "SELECT id, email, password, isAdmin FROM person WHERE email = ? AND password = ?";

        PreparedStatement ps = connection.prepareStatement(isAdmin);
        ps.setString(1, email);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        Person person = new Person();

        if (rs.next()) {
            person.setId(rs.getLong("id"));
            person.setEmail(rs.getString("email"));
            person.setPassword(rs.getString("password"));
            person.setAdmin(rs.getBoolean("isAdmin"));
        } else {
            ArrayList<Error> list = new ArrayList<>();
            list.add(Error.UNAUTHENTICATED_USER);
            throw new AppException(list);
        }
        return person;
    }
}
