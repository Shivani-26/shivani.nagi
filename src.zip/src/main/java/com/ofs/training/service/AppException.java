package com.ofs.training.service;

import java.util.ArrayList;

public class AppException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    ArrayList<Error> list = new ArrayList<>();
    private Error error;
    private Exception exception;

    public ArrayList<Error> getList() {
        return list;
    }

    public void setList(ArrayList<Error> list) {
        this.list = list;
    }

    public AppException(ArrayList<Error> list) {
        this.list = list;
    }

    public AppException(Error error, Throwable cause) {
        super(cause);
    }

    public AppException(Error error) {
        this.error = error;
    }

    public AppException(Exception exception) {
        this.exception = exception;
    }

    @Override
    public String getMessage() {
        return toString();
    }
}
