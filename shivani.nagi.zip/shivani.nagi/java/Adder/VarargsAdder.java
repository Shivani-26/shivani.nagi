public class VarargsAdder {

    static int add(int...number) {

        System.out.println("Number of arguments : " + number.length);
        System.out.println("The sum is");
        int sum = 0;
        for (int x : number)
        sum = sum + x;
        return sum;
    }

    public static void main(String[] args) {
        System.out.println(add(5, 6, 7));
        System.out.println(add(5, 6, 7, 8 ,9));
    }
}