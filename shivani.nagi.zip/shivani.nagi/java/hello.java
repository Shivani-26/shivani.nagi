class HelloOFS{
    public static void main(String args[]) {

        System.out.println("Hello OFS");
    }
}

class Hello {

    Hello(){
    System.out.println("hi OFS");
    }
}