package java;

public class TypeGetter {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object divOne = 100 / 24;
		System.out.println(div.getClass().getTypeName());

		Object divTwo = 100.10 / 10;
		System.out.println(div1.getClass().getTypeName());

		Object divThree = 'Z' / 2;
		System.out.println(div2.getClass().getTypeName());

		Object divFour = 10.5 / 0.5;
		System.out.println(div3.getClass().getTypeName());

		Object divFive = 12.4 % 5.5;
		System.out.println(div4.getClass().getTypeName());

		Object divSix = 100 % 56;
		System.out.println(div5.getClass().getTypeName());

	}

}

