import java.util.Scanner;

public class Number {

    // static void execute()
    public static void main(String[] args) {

        // Console console = getConsole()
        // console.print(getIntger())
        Scanner scan = new Scanner(System.in);
        System.out.println("enter integer");
        int aNumber = scan.nextInt();

        if (aNumber >= 0) {
            if (aNumber == 0) {

            // Console console = getConsole()
            // console.print(print first string)
            System.out.println("first string");
            } else {

                // Console console = getConsole()
                // console.print(print second and third string)
                System.out.println("second string");
                System.out.println("third string");
            }
        }
    }
}
