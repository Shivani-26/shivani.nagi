// class ObjectEquality
public class ObjectEqualityWithEnum {

    // enum ComputerHardware
    enum ComputerHardware {
    MONITOR,
    CPU,
    KEYBOARD,
    MOUSE;
    }

    // static void execute()
    public static void main(String[] args) {

        // Console console = getConsole()
        // console.print(equality of the values using .equals())
        System.out.println(ComputerHardware.MONITOR.equals(ComputerHardware.CPU);

        // Console console = getConsole()
        // console.print(equality of the values using ==)
        if (ComputerHardware.MONITOR == ComputerHardware.CPU) {
            System.out.println("the values are equal by reference");
        } else {
            System.out.println("the values are equal by reference");
        }
    }
}