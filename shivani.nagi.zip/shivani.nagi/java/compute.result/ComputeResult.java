public class ComputeResult {
    public static void main(String[] args) {

        String original = "software";
        StringBuilder result = new StringBuilder("hai");
        int index = original.indexOf('f');

        // result.setCharAt(0, original.charAt(4));
        // result.setCharAt(1, original.charAt(original.length() - 2));
        // result.insert(1, original.charAt(4));
        result.append(original.substring(1,3));
        // result.insert(3, (original.substring(index, index + 2)));

        System.out.println(result);
        System.out.println(index);
    }
}
