public class ObjectEquality {

    // class ObjectEquality
    public static void main(String[] args) {

        // static void execute()
        String firstName = "shivani";
        String secondName = "ruchira";
        String thirdName = "shivani";

        // Console console = getConsole()
        // console.print(equality of the values using .equals())
        System.out.println(firstName.equals(secondName));
        System.out.println(firstName.equals(thirdName));

        // Console console = getConsole()
        // console.print(equality of the values using ==)
        if (firstName == secondName) {
            System.out.println("firstName is equal to secondName by reference");
        } else {
            System.out.println("firstName is not equal to secondName by reference");
        }

        if (firstName == thirdName) {
            System.out.println("firstName is equal to thirdName by reference");
        } else {
            System.out.println("firstName is not equal to thirdName by reference");
        }
    }
}
