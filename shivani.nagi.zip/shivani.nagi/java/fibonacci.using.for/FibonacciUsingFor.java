import java.util.Scanner;

// class FibonacciUsingFor
public class FibonacciUsingFor {

    // static void execute()
    public static void main(String[] args) {

        int n1 = 0, n2 = 1, n3;
        Scanner scan = new Scanner(System.in);

        // Console console = getConsole()
        // console.print(getInput)
        System.out.println("enter integer");
        int n = scan.nextInt();

        // Console console = getConsole()
        // console.print(beginning values of the series)
        System.out.println("The fibonicci series is :" + n1);

        // generateSeries(n)
        for (int i = 2; i <= n; i++) {
            n3 = n1 + n2;

            // Console console = getConsole()
            // console.print(nextValue)
            System.out.print(" " + n3);
            n1 = n2;
            n2 = n3;
        }
    }
}