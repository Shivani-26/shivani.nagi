// class StringConcatenation
public class StringConcatenation {

    // static void execute()
    public static void main(String[] args) {

        String firstString = "Hi, ";
        String secondString = "mom.";

        // concatenate(string1, string2)
        String result1 = firstString + secondString;

        // Console console = getConsole()
        // console.print(result1)
        System.out.println(result1);

        String result2 = firstString.concat(secondString);

        // Console console = getConsole()
        // console.print(result1)
        System.out.println(result2);
    }
}
