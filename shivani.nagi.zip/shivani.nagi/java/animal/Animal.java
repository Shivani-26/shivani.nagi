public class Animal {

    public int legs;
    public int eyes;

    public void run(int distance) {
        int speed = legs * distance;
        System.out.println("The speed of the animal is" + speed);
    }
    
    public static void main(String[] args) {
    	Animal animal = new Animal();
    	animal.legs = 2;
    	animal.run(5);
    }
}