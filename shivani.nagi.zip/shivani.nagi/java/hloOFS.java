class hloofs{
       public static void main(String args[]){
       System.out.println("Hello OFS");
       }
   }

class hlo{
       hlo(){
       System.out.println("hi OFS");
       }
   }