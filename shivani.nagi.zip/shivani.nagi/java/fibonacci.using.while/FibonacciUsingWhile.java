import java.util.Scanner;

// class FibonacciUsingWhile
public class FibonacciUsingWhile {

    // static void execute()
    public static void main(String[] args) {

        int n1 = 0, n2 = 1, n3;

        // Console console = getConsole()
        // console.print(getInput)
        Scanner scan = new Scanner(System.in);
        System.out.println("enter integer");
        int n = scan.nextInt();

        // Console console = getConsole()
        // console.print(beginning values of the series)
        System.out.print("The fibonicci series is :" + n1);
        int i = 0;

        // generateSeries(n)
        while (i <= n) {
            n3 = n1 + n2;
            System.out.print(" " + n3);
            n1 = n2;
            n2 = n3;
            i++;
        }
    }
}
