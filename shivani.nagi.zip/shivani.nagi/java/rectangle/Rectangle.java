public class Rectangle {

    int width;
    int height;
    int area() {
        int a = width * height;
        return a;
    };

    public static void main(String[] args) {
        Rectangle myRect = new Rectangle();
        myRect.width = 4;
        myRect.height = 5;
        System.out.println("myRect's width is " + myRect.width);
    }
}
