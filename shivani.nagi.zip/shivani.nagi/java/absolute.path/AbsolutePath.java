import java.io.File;

// class AbsolutePath
public class AbsolutePath {

    // static void execute()
    public static void main(String[] args) {

        File file = new File("AbsolutePath.class");
        String fpath = file.getAbsolutePath();

        // Console console = getConsole()
        // console.print(absolute path)
        System.out.println("Absolute path is : " + fpath);
    }
}
