import java.util.Arrays;
public class SortArray{

    // static void execute()
    public static void main(String[] args) {

        String[] cities = { "Madurai",
                            "Thanjavur",
                            "TRICHY",
                            "Karur",
                            "Erode",
                            "trichy",
                            "Salem" };

        // Console console = getConsole()
        // console.print(sortedArray)
        System.out.println("this is the sorted array : ");

        // TODO:sort the arrays
        Arrays.sort(cities);

        // Console console = getConsole()
        // console.print(cities)
        System.out.println(cities);
            for (int i = 0; i < cities.length; i++) {
            if (i % 2 == 0) {
                System.out.println(cities[i].toUpperCase());
            } else {
                System.out.println(cities[i]);
            }
        }
    }
} 
