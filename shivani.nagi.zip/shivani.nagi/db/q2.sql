SELECT stu.roll_no, stu.name, stu.gender, stu.dob, stu.email, stu.phone, stu.address, col.col_name
       ,dep.dept_name, uni.univ_name, res.semester
       FROM edu_student AS stu
	   INNER JOIN edu_college AS col ON stu.college_id=col.id AND col.city IN('salem','vilupuram') 
	   INNER JOIN edu_semester_result AS res ON stu.id=res.stud_id  AND res.semester=8
	   INNER JOIN edu_univ uni ON col.univ_code=uni.univ_code AND uni.univ_name IN('Anna University','VIT')
       INNER JOIN edu_cdept AS cdep ON stu.college_id=cdep.cdept_id 
	   INNER JOIN edu_dept AS dep ON cdep.udept_code=dep.dept_code ;