INSERT INTO edu_semester_fee(cdept_id, stud_id, semester, amount, paid_year, paid_status)

            VALUES(2, 45, 02, 20000, 2018, 'unpaid' ) 
				      ,(2, 46, 02, 20000, 2018, 'unpaid' );		
                      
INSERT INTO edu_student(college_id, cdept_id, roll_no, `name`, dob, gender, email, phone, address, academic_year)						 
						 
			VALUES(2, 7, 'c204', 'abi', '1996-07-31', 'f', 'abi@gmail', 8497755058, '90,reddiyar st., panamarathupatti, salem', 2018 )	                     
				 ,(2, 8, 'c205', 'ramya', '1996-01-28', 'f', 'ramya@gmail', 8497777445, '90,gandhi nagar, panamarathupatti, salem', 2018 );	



SELECT stu.name, fee.cdept_id, fee.stud_id, fee.semester, fee.amount, fee.paid_year, 
       fee.paid_status, col.col_name, uni.univ_name
       FROM edu_college AS col 
       INNER JOIN edu_univ AS uni ON uni.univ_code=col.univ_code
	   INNER JOIN edu_student AS stu ON stu.college_id=col.id
	   INNER JOIN edu_semester_fee AS fee ON fee.stud_id=stu.id; 				 
						
						                 