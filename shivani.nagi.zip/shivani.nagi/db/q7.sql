CREATE VIEW view_sem_fee AS
            SELECT stu.id, stu.college_id, stu.cdept_id, stu.roll_no, stu.name, stu.phone,
		             fee.semester, fee.amount, fee.paid_year, fee.paid_status
	 	             FROM edu_student AS stu 
		             INNER JOIN edu_semester_fee AS fee ON fee.stud_id=stu.id;
		             
SELECT * FROM view_sem_fee ;						 	            
UPDATE view_sem_fee
       SET paid_status = 'paid', paid_year=2018 
       WHERE roll_no='c102';

UPDATE view_sem_fee
       SET paid_status = 'paid', paid_year=2018 WHERE roll_no  IN ('c102', 'c401', 'c503', 'c204');
		    
              
       