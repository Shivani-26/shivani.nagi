INSERT INTO edu_dept(dept_code, univ_code, dept_name)
             
             VALUES  ('d1ec', 'u001', 'ece' )
                   , ('d2ae', 'u001', 'aeronautical')
                   , ('d3cs', 'u001', 'cse')
                   , ('d4cv', 'u001', 'civil' )
                   , ('d5it', 'u001', 'it')         
                   , ('d6ma', 'u001', 'marine')               
				    	 , ('cs01', 'u002', 'cse') 
				   	 , ('it02', 'u002', 'it')
				   	 , ('cv03', 'u002', 'civil')
				   	 , ('ee04', 'u002', 'eee')
				     	 , ('mc05', 'u002', 'mech')
				   	 , ('ec06', 'u002', 'ece')
				   	 , ('01cs', 'u003', 'cse')
				   	 , ('02cv', 'u003', 'civil')
				   	 , ('03it', 'u003', 'it')
				   	 , ('04ec', 'u003', 'ece')
				   	 , ('d01', 'u004', 'cse') 
				   	 , ('d02', 'u004', 'ece')
				   	 , ('d03', 'u004', 'civil')
				   	 , ('d04', 'u004', 'mech')
				   	 , ('d05', 'u004', 'eee')
				   	 , ('aer5', 'u005', 'aero') 
				   	 , ('agr5', 'u005', 'agri')
				   	 , ('cse5', 'u005', 'cse')
				   	 , ('civ5', 'u005', 'civil')
				   	 , ('ec05', 'u005', 'ece')
				   	 , ('ee05', 'u005', 'eee')
				   	 , ('dpt4', 'u006', 'plastic')
				   	 , ('dpt5', 'u006', 'textile')
				   	 , ('dpt6', 'u006', 'printing');
				   	 
INSERT INTO edu_univ(univ_code, univ_name) 
					VALUES  ('u001', 'Anna University')
					,		('u002', 'Annamalai University')
					, 		('u003', 'CIT')
					,		('u004', 'Periyar Uiversity')
					,		('u005', 'VIT')
					,		('u006', 'SRM');		
										 
				   	 

INSERT INTO edu_college(univ_code, col_code, col_name, city, state, year_opened)
			
			VALUES ('u001', '6105', 'DGCT', 'salem', 'tamilnadu', 2010)  
				  , ('u001', '1234', 'KIOT', 'salem', 'tamilnadu', 2008) 
				  , ('u001', '1342', 'Sona', 'salem', 'tamilnadu', 1996) 
				  , ('u002', '2423', 'IFET', 'vilupuram', 'tamilnadu', 1970) 
				  , ('u002', '2563', 'subbarayalu college', 'coimbatore', 'tamilnadu', 1990) 
				  , ('u003', '3457', 'coimbatore institute of technology', 'coimbatore', 'tamilnadu', 2004 ) 
				  , ('u004', '4325', 'Salem college of engineering', 'salem', 'tamilnadu', 2007 ) 
				  , ('u004', '4897', 'paavi college of engineering', 'salem', 'tamilnadu', 1998 ) 
				  , ('u005', '5197', 'skp engineering college', 'thiruvannamalai', 'tamilnadu', 1996 ) 
				  , ('u005', '5243', 'vellore institute of technology','vellore', 'tamilnadu', '1980' )  
				  , ('u006', '6387', 'srimanakula vinayagar college of engineering', 'madagadipet', 'pondicherry', 1989 ) 
				  , ('u006', '6853', 'valliyammai engineering college', 'chennnai', 'tamilnadu', 1978);
				  

						 
INSERT INTO edu_designation(`name`, rank)
							VALUES ('Principal', 1)
							      ,('HOD', 2)
							      ,('professor', 3)
							      ,('Assistant Professor', 4);		
									
INSERT INTO edu_employee(college_id, cdept_id, desig_id, `name`, dob, email, phone)
			     VALUES (1, 1, 1, 'sumathi',   '1970-06-23', 'sumathi@gmail.com', 9827686325 )
				       ,(1, 1, 2, 'saravanan', '1965-09-23', 'saravanan@gmail.com', 9876564325)
					   ,(1, 1, 3, 'murali',    '1980-11-06', 'murali@gmail.com', 8760943521)
				       ,(1, 1, 4, 'meena',     '1985-08-17', 'meena@gmail.com', 7501298354)
				       ,(1, 2, 2, 'mirvin',    '1967-03-28', 'mirveen@gmail.com', 9536271453)
				       ,(1, 2, 3, 'kalai',     '1997-07-07', 'kalai@gamil.com', 6372891654)
				       ,(1, 2, 4, 'raman',     '1996-05-26', 'raman@gmail.com', 9080765342)
					   
					   ,(2, 1, 1, 'praveen', '1970-07-23', 'praveen@gmail.com', 9827686324 )
				       ,(2, 1, 2, 'ranjith', '1965-08-23', 'ranjith@gmail.com', 9876564324)
					   ,(2, 1, 3, 'ragavan', '1980-10-06', 'ragavan@gmail.com', 8760943520)
				       ,(2, 1, 4, 'malar',   '1985-09-17', 'malar@gmail.com', 7501298353)
				       ,(2, 2, 2, 'sanjai',  '1967-05-28', 'sanjai@gmail.com', 9536271452)
				       ,(2, 2, 3, 'mithran', '1997-04-07', 'mithran@gamil.com', 6372891653)
				       ,(2, 2, 4, 'srija',   '1996-03-26', 'srija@gmail.com', 8080765341)
					   
					   ,(5, 1, 1, 'naveen',  '1970-06-24', 'naveen@gmail.com', 8827686324 )
				       ,(5, 1, 2, 'ruchira', '1965-09-05', 'ruchira@gmail.com', 8876564324)
					   ,(5, 1, 3, 'ragav',   '1980-11-24', 'ragav@gmail.com', 7760943520)
				       ,(5, 1, 4, 'selvi',   '1985-08-08', 'selvi@gmail.com', 8501298353)
				       ,(5, 2, 2, 'jayaram', '1967-03-29', 'jayaram@gmail.com', 8536271452)
				       ,(5, 2, 3, 'mani',    '1997-07-08', 'mani@gamil.com', 7372891653)
				       ,(5, 2, 4, 'ragul',   '1996-05-27', 'ragul@gmail.com', 8080765341)
				       
					   ,(8, 1, 1, 'shivani', '1970-07-25', 'shivani@gmail.com', 8727686324 )
				       ,(8, 1, 2, 'ayshwariya', '1965-08-25', 'ayshwariya@gmail.com', 8676564324)
					   ,(8, 1, 3, 'sugandapriya', '1980-10-08', 'sugandapriya@gmail.com', 7860943520)
				       ,(8, 1, 4, 'subha', '1985-09-19', 'subha@gmail.com', 8801298353)
				       ,(8, 2, 2, 'sowmiya', '1967-04-30', 'sowmiya@gmail.com', 8036271452)
				       ,(8, 2, 3, 'sundar', '1997-08-09', 'sundar@gamil.com', 7172891653)
				       ,(8, 2, 4, 'rahul', '1996-06-28', 'rahul@gmail.com', 8980765341)
					   
					   ,(12, 1, 1, 'abinaya', '1976-07-25', 'abinaya@gmail.com', 8727586324 )
				       ,(12, 1, 2, 'deepti', '1965-05-08', 'deepti@gmail.com', 8676554324)
					   ,(12, 1, 3, 'gokila', '1985-08-10', 'gokila@gmail.com', 7860953520)
				       ,(12, 1, 4, 'dhivya', '1989-09-19', 'dhivya@gmail.com', 8801098353)
				       ,(12, 2, 2, 'prasanna', '1977-04-30', 'prasanna@gmail.com', 8035271452)
				       ,(12, 2, 3, 'tamil', '1987-09-08', 'tamil@gamil.com', 7172791653)
				       ,(12, 2, 4, 'sabari', '1976-06-28', 'sabari@gmail.com', 8980865341);
						 

INSERT INTO edu_student(college_id, cdept_id, roll_no, `name`, dob, gender, email, phone, address, academic_year)						 
						 
					VALUES(1, 1, 'c101', 'abinaya',    '1996-07-13', 'f', 'abinaya@gmail', 9487755058, '42,reddiyar st., panamarathupatti, salem', 2018 )	 
				         ,(1, 5, 'c102', 'ayshwariya', '1996-08-09', 'm', 'ayshwariya@gmail', 9487755056, '52,shevapet, salem', 2018  )
						 ,(1, 8, 'c103', 'vaishnavi',  '1996-08-08', 'f', 'vaishnavi@gmail', 9487755057, '12,gandhi nagar, salem', 2018  )
						 ,(1, 8, 'c104', 'pavithra',   '1996-12-23', 'f', 'pavithra@gmail', 9487755058, '56,annadhanapatti, salem', 2018  )
						 ,(1, 10, 'c105', 'bavani',    '1996-12-12', 'f', 'bavani@gmail', 9487755059, '34,ammapet, salem', 2018  )
						 ,(2, 2, 'c201', 'parvathi',   '1996-08-26', 'f', 'parvathi@gmail', 9487755050, '5,ammapet, salem', 2018  )
						 ,(2, 4, 'c202', 'sabari',     '1996-08-01', 'm', 'sabari@gmail', 9487755046, '23,gugai, salem', 2018  )
						 ,(2, 9, 'c203', 'monica',     '1996-08-30', 'f', 'monica@gmail', 9487755036, '67,prabath, salem', 2018  )
						 ,(3, 3, 'c301', 'sekar',      '1997-02-09', 'm', 'sekar@gmail', 9487755026, '23,seelanaiyakanpatti, salem', 2018  )
						 ,(3, 7, 'c302', 'ruba',       '1996-02-07', 'f', 'ruba@gmail', 9487755016, '89,shevapet, salem', 2018  )
						 ,(3, 12, 'c304', 'rubasri',   '1996-02-02', 'f', 'rubasri@gmail', 9487755006, '01,agraharam, salem', 2018  )
						 ,(3, 14, 'c305', 'nandhini',  '1995-02-11', 'f', 'nandhini@gmail', 9487755096, '7,koranguchavadi, salem', 2018  )
				       ,(4, 15, 'c401', 'nandhitha', '1996-02-23', 'f', 'nandhitha@gmail', 9487755086, '12,gandhinagar,vilupuram', 2018  )
						 ,(4, 17, 'c402', 'subha',     '1996-02-14', 'f', 'subha@gmail', 8487755076, '23,prasannanagar,vilupuram', 2018  )
						 ,(4, 20, 'c403', 'sri',       '1997-02-08', 'm', 'sri@gmail', 9487755066, '52,almasnagar, kadalur', 2018  )
						 ,(4, 22, 'c404', 'tamilselvan','1996-02-18', 'm', 'tamilselvan@gmail', 9487755056, '89,madhunagar, chidhambaram', 2018  )
						 ,(5, 16, 'c501', 'trisigan',   '1996-02-19', 'm', 'trisigan@gmail', 9487755156, '6,dhadhagapatti, coimbatore', 2018  )
						 ,(5, 18, 'c502', 'ramamoorthi','1996-01-09', 'm', 'ramamoorthi@gmail', 9487755256, '12,kondalampatti, salem', 2018  )
						 ,(5, 19, 'c503', 'manoj',      '1996-12-09', 'm', 'manoj@gmail', 9487755356, '52,shevapet, coimbatore', 2018  )
						 ,(5, 21, 'c504', 'ram',        '1997-01-01', 'm', 'ram@gmail', 9487755456, '31,oldbusstand, erode', 2018  )
				         ,(5, 24, 'c505', 'raja',       '1996-01-05', 'm', 'raja@gmail', 9487755556, '67,shevapet, coimbatore', 2018  )
				         
						 ,(6, 25, 'c601', 'anitha', '1996-01-09', 'f', 'anitha@gmail', 9487756756, '43,poolavari, salem', 2018  )
						 ,(6, 26, 'c602', 'anusha', '1996-01-11', 'f', 'anusha@gmail', 9487755756, '31,uthamasolapuram, coimbatore', 2018  )						 
						 ,(6, 27, 'c603', 'deepti', '1996-01-15', 'f', 'deepti@gmail', 9480155856, '26,elim nagar,erode', 2018  )
						 ,(6, 28, 'c604', 'keerthi', '1997-01-19', 'f', 'keerthi@gmail', 9480255956, '50,shevapet, salem', 2018  )
						 
						 ,(7, 29, 'c701', 'hanusri', '1995-01-28', 'f', 'hanusri@gmail', 9480455056, '5,shevapet, salem', 2018  )
						 ,(7, 32, 'c702', 'sahana', '1996-05-09',  'f', 'sahana@gmail', 9480555056, '56,fairlands, salem', 2018  )
						 ,(7, 34, 'c703', 'srimathi', '1996-05-04', 'f', 'srimathi@gmail', 9480655056, '17,fairlands, salem', 2018  )                            
						 ,(7, 36, 'c704', 'madhumitha', '1996-05-01', 'f', 'madhumitha@gmail', 9480755056, '7,murugan st., erode', 2018  )
						 ,(8, 30, 'c801', 'nisha', '1996-05-09', 'f', 'nisha@gmail', 9480955056, '2,linemedu, salem', 2018  )
						 ,(8, 31, 'c802', 'kanchana', '1996-05-09', 'f', 'kanchana@gmail', 9481055056, '43,gugai, salem', 2018  )
						 ,(8, 33, 'c803', 'archana', '1996-05-09', 'f', 'archana@gmail', 9481155056, '52,pudhur, salem', 2018  )
						 ,(8, 35, 'c804', 'anu', '1997-07-09', 'f', 'anu@gmail', 9481255056, '43,gugai, salem', 2018  )
						 
						 ,(9, 37,  'c901', 'bavya', '1996-07-09', 'f', 'bavya@gmail', 9481355056, '45,gandhinagar,thiruvannamalai', 2018  )
						 ,(9, 39,  'c902', 'barathi', '1996-07-09', 'm', 'barathi@gmail', 9481455056, '34,thirukovilur,thiruvannamalai', 2018  )
						 ,(9, 41,  'c903', 'maniraj', '1996-04-09', 'm', 'maniraj@gmail', 9481555056, '34,sevainagar,kadalur', 2018  )
						 ,(10, 38, 'c001', 'manigandan', '1996-04-09', 'm', 'manigandan@gmail', 9481655056, '23,rajaji st.,vellore', 2018  )
                   ,(10, 40, 'c002', 'manohar', '1996-04-09', 'm', 'manohar@gmail', 9482155056, '08,rajaji st.,vellore', 2018  )
                   ,(10, 42, 'c003', 'dhivya', '1998-04-09', 'f', 'dhivya@gmail', 9482255056, '08,rajaji st.,vellore', 2018  )
						 ,(10, 44, 'c004', 'dhinesh', '1996-04-09', 'm', 'dhinesh@gmail', 9482355056, '76,gugaipalam,vellore', 2018  )
						
						 
						 ,(11, 48, 'c111', 'krishnan', '1998-10-09', 'm', 'krishnan@gmail', 9483755056, '52,perungudi, chennai', 2018  )
						 ,(11, 50, 'c112', 'gopal', '1996-10-09', 'm', 'gopal@gmail', 9483855056, '12,krishna nagar,pondicherry', 2018  )
						 ,(12, 47, 'c113', 'saranya', '1996-10-09', 'f', 'saranya@gmail', 9485655056, '1,nehru st.,chennai', 2018  )
						 ,(12, 49, 'c114', 'padma', '1996-10-09', 'f', 'padma@gmail', 9488955056, '3,shevapet, salem', 2018  );
						 
						 
INSERT INTO edu_cdept(udept_code,college_id)	
					
			VALUES   ('d1ec', 1)
				    ,('d3cs', 1) 
				    ,('d4cv', 1)
				 	,('d5it', 1)
				    ,('d1ec', 2)
				    ,('d2ae', 2)
				    ,('d3cs', 2)
					,('d6ma', 2)
				    ,('d4cv', 2)
				    ,('d5it', 2)
				    ,('d1ec', 3)
					,('d5it', 3)
					,('d3cs', 3)
					,('d6ma', 3)
						
						
                    ,('cs01', 4)
					,('it02', 4)
					,('ee04', 4)
				    ,('mc05', 4)
				    ,('ec06', 4)
				    ,('cs01', 5)
				    ,('it02', 5)
					,('cv03', 5)
					,('ee04', 5)
					,('ec06', 5)
                       
						
				    ,('01cs', 6)
				    ,('02cv', 6)
                    ,('03it', 6)
                    ,('04ec', 6)
				       
				    
				    ,('d01', 7)                  
                    ,('d03', 7)
					,('d04', 7)
                    ,('d05', 7)
				    ,('d01', 8) 
				    ,('d02', 8)
				    ,('d03', 8)
					,('d04', 8)
					
			        ,('aer5', 9)
                    ,('cse5', 9)                    
				    ,('civ5', 9)				    
                    ,('ec05', 9)                    
				    ,('ee05', 9)
				    
	                ,('agr5', 10)
                    ,('cse5', 10)
					,('civ5', 10)	
					,('ec05', 10)				
					,('ee05',10)
					,('dpt5', 11)
					,('dpt6', 11)
					,('dpt4', 12)                 
				    ,('dpt5', 12);
                    			
				       									 
						 						 																			 				  				  
				  
			  
	INSERT INTO edu_professor_syllabus(emp_id, syl_id, semester)			  
				                  
		       VALUES(2, 1, 01)
						 ,(3, 4, 01)
						 ,(4, 3, 01)
						 ,(5, 5, 02)					4
						 ,(6, 4, 02)
						 ,(7, 4, 02)
						 
						 ,(8, 7  , 01) 
						 ,(9, 8  , 01)
						 ,(10, 9 , 01)
						 ,(11, 10, 01)
						 ,(12, 12, 02)
						 ,(13, 13, 02)
						 ,(14, 13, 02)
						 
						 ,(15, 16, 01)
						 ,(16, 17, 01)
						 ,(17, 18, 01)
						 ,(18, 18, 01)
						 ,(19, 19, 02)
						 ,(20, 19, 02)
						 ,(21, 19, 02)
						 
						 ,(22, 22, 01)
						 ,(23, 23, 01)
						 ,(24, 22, 01)
						 ,(25, 28, 01)
						 ,(26, 28, 02)
						 ,(27, 26, 02) 
						 ,(28, 27, 02)
						 
						 ,(29, 20, 01)
						 ,(30, 20, 01)
						 ,(31, 24, 02)
						 ,(32, 25, 02)
						 ,(33, 24, 02) ;
						 
INSERT INTO edu_semester_result(stud_id, syl_id, semester, grade, credits, result_date)	
					    VALUES  (1, 1, 1, 'S', 10, '2017-12-09')
						       ,(2, 2, 1, 'A', 9, '2017-12-09') 
						       ,(3, 3, 1, 'S', 10, '2017-12-09')
						       ,(4, 4, 2, 'C', 7, '2018-06-12')
						       ,(5, 5, 2, 'A', 9, '2018-06-12')
						       ,(6, 6, 2, 'B', 8, '2018-06-12')
						       ,(7, 7, 1, 'S', 10, '2017-12-09')
						       ,(10, 12, 2, 'C', 7, '2018-06-12')
						       ,(10, 13, 2, 'A', 9, '2018-06-12')
						       ,(13, 14, 2, 'S', 10, '2018-06-12')
						       ,(13, 15, 1, 'C', 7, '2017-12-09')
						       ,(16, 18, 1, 'S', 10, '2017-12-09')
						       ,(16, 19, 2, 'C', 7, '2018-06-12')
						       ,(17, 16, 1, 'A', 9, '2017-12-09')
						       ,(17, 17, 1, 'A', 9, '2017-12-09')
						       ,(22, 20, 2, 'C', 7, '2018-06-12')
						       ,(23, 21, 2, 'C', 7, '2018-06-12')
						       ,(29, 22, 1, 'B', 8, '2017-12-09')
						       ,(29, 23, 1, 'S', 10, '2017-12-09')
						       ,(34, 26, 2, 'A', 9, '2018-06-12')
						       ,(36, 24, 2, 'C', 7, '2018-06-12')
						       ,(36, 25, 2, 'D', 6, '2018-06-12')
						       ,(39, 28, 2, 'C', 7, '2018-06-12');
						       
INSERT INTO edu_semester_fee(cdept_id, stud_id, semester, amount, paid_year, paid_status)

            VALUES    (1, 1, 01, 20000, 2018, 'paid' ) 						 
						   ,(1, 2, 01, 20000, 2018, 'unpaid' ) 
						   ,(1, 3, 01, 20000, 2018, 'paid' )
						   
						   ,(2, 4, 01, 20000, 2018, 'paid' )						   
						   ,(2, 5, 01, 20000, 2018, 'paid' ) 	
						   ,(5, 6, 01, 20000, 2018, 'unpaid' )
						   
						   ,(4, 7, 01, 20000, 2018, 'paid' ) 	
						   ,(9, 8, 01, 20000, 2018, 'paid' )
						   
						   ,(3, 9, 01, 20000, 2018,  'paid' ) 	
						   ,(7, 10, 01, 20000, 2018, 'unpaid' ) 	
						   ,(12, 11, 01, 20000, 2018,'unpaid' ) 	
						   ,(14, 12, 01, 20000, 2018,'paid' )
						   
						   ,(15, 13, 01, 20000, 2018, 'unpaid' ) 	
						   ,(17, 14, 01, 20000, 2018, 'unpaid' ) 	
						   ,(20, 15, 01, 20000, 2018, 'paid' ) 	
						   ,(22, 16, 01, 20000, 2018, 'paid' )
						                              
						   ,(16, 17, 01, 20000, 2018, 'paid' ) 	
						   ,(18, 18, 01, 20000, 2018, 'paid' ) 	
						   ,(19, 19, 01, 20000, 2018, 'unpaid' ) 	
						   ,(21, 20, 01, 20000, 2018, 'paid' )
						                              
						   ,(24, 21, 01, 20000, 2018, 'paid' ) 	
						   ,(25, 22, 01, 20000, 2018, 'paid' ) 	
						   ,(26, 23, 01, 20000, 2018, 'paid' ) 	
						   ,(27, 24, 01, 20000, 2018, 'unpaid' )
						                              
						   ,(28, 25, 01, 20000, 2018, 'paid' ) 	
						   ,(29, 26, 01, 20000, 2018, 'unpaid' ) 	
						   ,(32, 27, 01, 20000, 2018, 'paid' ) 	
						   ,(34, 28, 01, 20000, 2018, 'paid' );						       
						       						 
						 
						 
						
						 
					
						 
						
						 
						 
				  
				   

