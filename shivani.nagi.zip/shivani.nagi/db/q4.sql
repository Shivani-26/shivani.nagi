SELECT emp.id,emp.college_id, emp.cdept_id, emp.desig_id, emp.name, emp.dob, emp.email, emp.phone
       , dep.dept_name, col.col_name, emp.name, uni.univ_name
       
       FROM edu_employee AS emp
       INNER JOIN edu_college AS col ON col.id=emp.college_id
       INNER JOIN edu_cdept AS cdep ON emp.cdept_id=cdep.cdept_id
       INNER JOIN edu_dept AS dep ON cdep.udept_code=dep.dept_code
		 INNER JOIN edu_univ uni ON col.univ_code=uni.univ_code AND uni.univ_name IN('Anna University','VIT','Annamalai University', 'CIT')
       INNER JOIN edu_designation AS des ON emp.desig_id=des.id  ;
      