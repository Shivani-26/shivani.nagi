package com.ofs.training.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ofs.model.Person;


@Service
@Transactional
public class PersonService {

private static final Logger logger = LoggerFactory.getLogger(Person.class);

private SessionFactory sessionFactory;

public void setSessionFactory(SessionFactory sessionFactory) {
this.sessionFactory = sessionFactory;
}

// @Override
public void create(Person person) {
Session session = this.sessionFactory.getCurrentSession();
session.persist(person);
logger.info("Person created successfully, Person Details = " + person);
}

// @Override
public void update(Person person) {
Session session = this.sessionFactory.getCurrentSession();
session.update(person);
logger.info("Person updated successfully, Person Details = " + person);
}

@SuppressWarnings("unchecked")
// @Override
public List<Person> readAll() {
Session session = this.sessionFactory.getCurrentSession();
List<Person> personsList = session.createQuery("from Person").list();
for(Person person : personsList){
logger.info("Person List::" + person);
}
return personsList;
}

// @Override
public Person read(long id) {
Session session = this.sessionFactory.getCurrentSession();
Person person = (Person) session.load(Person.class, new Long(id));
logger.info("Person loaded successfully, Person details = " + person);
return person;
}

// @Override
public void delete(long id) {
Session session = this.sessionFactory.getCurrentSession();
Person person = (Person) session.load(Person.class, new Long(id));
if(null != person){
session.delete(person);
}
logger.info("Person deleted successfully, person details = " + person);
}
}