package com.ofs.training.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ofs.model.Address;

@Service
@Transactional
public class AddressService {

    private static final Logger logger = LoggerFactory.getLogger(Address.class);

    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    // @Override
    public void create(Address address) {
        Session session = this.sessionFactory.getCurrentSession();
        session.persist(address);
        logger.info("Person created successfully, Person Details = " + address);
    }

    // @Override
    public void update(Address address) {
        Session session = this.sessionFactory.getCurrentSession();
        session.update(address);
        logger.info("Address updated successfully, Person Details = " + address);
    }

    @SuppressWarnings("unchecked")
    // @Override
    public List<Address> readAll() {
        Session session = this.sessionFactory.getCurrentSession();
        List<Address> addressList = session.createQuery("from Address").list();
        for (Address address : addressList) {
            logger.info("Address List::" + address);
        }
        return addressList;
    }

    // @Override
    public Address read(long id) {
        Session session = this.sessionFactory.getCurrentSession();
        Address address = (Address) session.load(Address.class, new Long(id));
        logger.info("Address loaded successfully, Address details = " + address);
        return address;
    }

    // @Override
    public void delete(long id) {
        Session session = this.sessionFactory.getCurrentSession();
        Address address = (Address) session.load(Address.class, new Long(id));
        if (null != address) {
            session.delete(address);
        }
        logger.info("Address deleted successfully, person details = " + address);
    }
}